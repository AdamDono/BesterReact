import React, { useEffect, useState } from 'react'

const App = () => {

  const [showRegister, setShowRegister]= useState(false)
  const [showFailed, setShowFailed]= useState(false)
  const [showSuccess, setShowSuccess]= useState(false)
  const [showLanding, setShowLanding]= useState(true)

  useEffect(() => {
    setTimeout(() => {
      setShowLanding(false)
      setShowRegister(true)
    }, 5000)
  }, [])


  function registerOnSuccess() {
    setShowRegister(false)
    setShowSuccess(true)
  }

  function registerOnFail() {
    setShowRegister(false)
    setShowFailed(true)
  }

  return (
    <div className='app'>
      {showLanding && <Landing />}
      {showFailed && <Failed />}
      {showSuccess && <Success />}
      {showRegister && <Register registerOnSuccess={registerOnSuccess} registerOnFail={registerOnFail} />}
    </div>
  )
}

export default App


 function Register({registerOnSuccess, registerOnFail}) {
  return <>
   <h1>Register</h1>
   <br />
  <button onClick={registerOnSuccess}>Success</button>
  <button onClick={registerOnFail}>Fail</button>
 </> 

 }

 function Failed() {
  return <h1>Failed</h1>
 }

 function Success() {
  return <>
  <h1>Success</h1>

  </>
 }

 function Landing() {
  return <h1>Landing</h1>
 }